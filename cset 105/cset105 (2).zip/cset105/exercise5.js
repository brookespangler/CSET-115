//array sort
function getMinIndex(arr){ // returns index of minimum elements first 
    let minIndex = 0; 
    for(let i = 1; i < arr.length; i++){
        if(arr[i] < arr[minIndex]) {
            minIndex = i;
        }
    }
    return minIndex;
}
function customSort(arr){ // creates new array that holds sorted elements
    let sortedArr = [];

    while (arr.length > 0) {
        let minIndex= getMinIndex(arr);
        sortedArr.push(arr[minIndex]); // adds minimum element to new sorted array first in the list. 
        arr.splice(minIndex, 1); // remove element from og array 
    }
    return sortedArr;
}
let unsortedArr= [69, 53, 23, 10, 1, 4, 63, 80, 9];
let sortedArr= customSort(unsortedArr); 
console.log(sortedArr);