 //flattening
 const arr = [[1, 2, 3], [4, 5], [6, 7, 8, 9]]; //multiple arrays

const flattenedArr = arr.reduce((accumulator, currentValue) => {  //use reduce and concat to make it one array and combine them.  
  return accumulator.concat(currentValue);
}, []);

console.log(flattenedArr);