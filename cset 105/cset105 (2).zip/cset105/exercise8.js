//array some
const arr=[1,2,3,4,5,6,7,8];
function checkSome(){
  for(let num of arr){
    //loop through array
    if(num<5){
      return false;
      
    }
  }
  return true;

}
console.log(checkSome()); //prints false
