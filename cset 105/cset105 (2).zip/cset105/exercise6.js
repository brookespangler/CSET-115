//array concat
 const array1=[5,10,15,];
 const array2=[20,25,30];
 //two arrays that will be concatenated together
 function addArrays(array1, array2){
   const result=[];
   for (let item of array1){
     result.push(item)
   } 
   //adds numbers in each array to the result
   for (let item of array2){
     result.push(item);
   }
   ///loop through second array
   return result;
 }
 console.log(addArrays(array1, array2));//prints the arrays together
 