//array reverse
let number = ['indigo','purple','5','6','7','8'];

function invert() { //split into array of characters
//define the range, 0 to the length -1, the index.
let left = 0;
let right = number.length- 1;
// Swap characters until middle is reached.
while (left < right) {
// Swap characters
[number[left], number[right]] = [number[right], number[left]];
// left increases as right decreses
left++;
right--;
}
  console.log(number);
}
// Join the array back into a string
invert();