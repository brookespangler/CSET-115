//array join
const arr = ["h", "e", "l", "l", "o"];

function myJoin(array, seperate = ''){
let result=[''];// empty string that will hold the result

for (let i = 0; i < array.length; i++){
    result += array[i]; // adds each letter to the result

    if (i < array.length -1){
        result += seperate; // add the seperator if it isnt the last element
        }
    } 
    return result;
}
console.log(myJoin(arr,'')); 