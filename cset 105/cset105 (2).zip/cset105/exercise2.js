//flatten with own loop
function loop(initialValue, testFunction, updateFunction, bodyFunction) {
    while (testFunction(initialValue)) {  
        bodyFunction(initialValue);       
        initialValue = updateFunction(initialValue); // updating the value
    }
}
const nestedArray = [[1, 2], [3, 4], [5, 6]];  // nested array thats getting flattened
let flattened = [];  // This will accumulate the flattened values
let index = 0;  // Start with 0
loop(
    index,                            
    i => i < nestedArray.length,    
    i => i + 1,  // updates and increments the index
    i => { flattened = flattened.concat(nestedArray[i]); }  // Body function: concat sub-array at i to the flattened array
);

console.log(flattened); // print final array

