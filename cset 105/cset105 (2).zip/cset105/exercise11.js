// array find
function ownFind(array, callback){
    for (let i=0; i < array.length; i++) {
        if (callback(array[i], i, array)) {
            return array[i] // return first element that works nder the condition
        }
    }
    return undefined; // undefined if no element fits the condition
}
const arr= [100, 99, 98, 97, 96, 95, 94, 93, 92, 91]; 

const found = ownFind(arr, element => element > 91); // returns the first function in the array that is greater than 91.
console.log(found);// in this case 100 is the first number in the array that is greater than 91.