//array map 
const arr1 =[2,4,6]; //original array
const arr2= []; //placeholder array

for (let i = 0; i < arr1.length; i++){ //map array without using higher order function or map
    arr2.push(arr1[i] * 5); 
}
console.log(arr2); //prints the new array