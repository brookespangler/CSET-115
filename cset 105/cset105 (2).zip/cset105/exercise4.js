//array filter 
const number= [2,3,4,5,6,7,8,9,10]; //original array 
const allNumbers = [];
for( let i=0; i < number.length; i++){ 
    if(number[i] >= 7) {
        allNumbers.push(number[i]); // outputs numbers that are 7 or greater without using filter 
    }
} 
console.log(allNumbers); // new and updated array printed