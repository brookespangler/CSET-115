//array fill
const arrColor = new Array(6); // array has 6 elements

function fillArray (fillContent) {//loop through each element in arrColor
  for (i=0;i<arrColor.length;i++) { //check if current element is not equal to 'fillcontent'
    if (arrColor[i] !== fillContent) {//if element isnt equal to fillcontent replace it with the fillconcent.
      arrColor[i] = fillContent;
    }
  }
  console.log(arrColor);
}

fillArray('pink'); // prints pink 6 times
