//array includes
const array=[1,2,3,4,5,6];
function checkIncludes(array,value){
    return array.some(item => item===value);
  
}
console.log(checkIncludes(array,3));
console.log(checkIncludes(array, 9));
//prints true 
//prints false
