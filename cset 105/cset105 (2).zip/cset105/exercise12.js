//array findIndex
function myIndex(array, callback){
    for(let i = 0; i < array.length; i++){
        if (callback(array[i], i, array)){ //doesnt use strict comparison
            return i;// return the index of the name that is selected , and satisfies the condition.
        }
    }
    return -1; //if condition isn't satisfied, return -1.
}
const arrMyFriends = ["Annabel", "Andrew", "Dallas", "Grace", "Kendall", "Caleb"]
const indexFinder= myIndex(arrMyFriends, element => element === "Dallas"); // find index of "Dallas"
console.log(indexFinder); // prints 2, because index starts at 0 .

  