// array unshift
const arrVeggie = [ 'carrot', 'celery', 'broccoli', 'onion'
];

let unshiftedArr = []; 
let index = 1; //index still starting at 1, even though it isnt used in this case
let unshiftItem = ['carrot']; // item needed to unshift

function unshift () {
  unshiftedArr = unshiftItem.concat(arrVeggie);// concat unshiftItem which contains the carrot element to the beginning of the array. 
  unshift = unshiftedArr.length; //reassigns unshift to the length of new array after the unshift operation
  console.log(unshift);
  console.log(unshiftedArr);
}

unshift();
