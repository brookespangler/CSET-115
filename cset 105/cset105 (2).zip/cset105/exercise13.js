//array indexof
function myIndexOf(array, searchElement){
    for(let i = 0; i < array.length; i++){
     if (array[i] === searchElement){ //uses strict comparison 
             return i;// return the index of the name that is selected , and satisfies the condition. 
         }
     }
     return -1; //if element isn't found, return -1.
 }
 const arrMyFriends = ["Annabel", "Andrew", "Dallas", "Grace", "Kendall", "Caleb"] 
 const indexFinder= myIndexOf(arrMyFriends,"Andrew") //
 
 console.log(indexFinder); // prints 1, because index starts at 0 . 