//array shift
const arrVeggie = [ 'carrot', 'celery', 'broccoli', 'onion'
]; 

let shiftedArr = []; //will hold the final shifted array
let index = 1; // make the index 1 instead of 0
let shiftedIndex = arrVeggie[0]; //stores "carrot' in shiftedIndex"

function loop(initialValue, testFunction, updateFunction, bodyFunction) {
    while (testFunction(initialValue)) {
        bodyFunction(initialValue);
        initialValue = updateFunction(initialValue);
    }
}

loop(
    index, // initial value for loop, and skips the first element because it is 0. 
    i => i < arrVeggie.length, //continue looping while index is less than length.
    i => i + 1,     
    i => { shiftedArr = shiftedArr.concat(arrVeggie[i]); }  //concat the current vegetables in shiftedArr
);

console.log(shiftedIndex); //outputs first element of 0, which is carrot.
console.log(shiftedArr); //Output everything after 0 index in the array.