//array every 
const arr=[1,2,3,4,5,6,7]
function checkEvery(){
  for (let num of arr){
  if (num >=5){
    console.log('true');
    return;
  }
    console.log('false');
  
  }
}
checkEvery();
//prints true
