/*2 JS Objects*/
/*JS OBJECT 1*/
var person = {
    name: {
        firstName: "Brooke",
        lastName: "Spangler",
    },
    age: 18,
    school: "Thaddeus Stevens",
    hobby: ["Music", "Gym", "Shopping"],
    greet: function() {
        console.log("My name is " + this.name.firstName + " " + this.name.lastName);
    },
    full: function() {
        console.log("I go to " + this.school + " and my hobbies are " + this.hobby.join(", "));
    }
};

person.greet();
person.full();
/*JS OBJECT 2*/
let album={
    title:"BRAT",
    singer: "Charli XCX",
    songs: 15,
    producers: ["Charli XCX"," A.G Cook", "and George Daniels" ],
    play: function(){
        console.log("this album is produced by," + this.producers);
    }
};
console.log("Ttile", album.title);
console.log("Artist", album.singer);
album.play(); 

/*2 JS JSON*/

/*JSON 1*/
let string= JSON.stringify({
    "italianFood": "pasta",
    "mexicanFood": ["Burrito"]
});
console.log(string);
console.log(JSON.parse(string).mexicanFood);

/*JSON 2*/
let IT = JSON.stringify({
    "languages":{
        "frontend": ["Javascript", " HTML", "CSS"],
        "backend": ["Java", "Ruby", "C#"]
    },
   "devices":{
        "computers":["MacOs", "Windows",],
        "phones": ["Iphone", "samsung", "LG" ]
   }
});
console.log(IT);
console.log(JSON.parse(IT). languages.frontend);
console.log(JSON.parse(IT). languages.backend);
console.log(JSON.parse(IT). devices.computers);
console.log(JSON.parse(IT). devices.phones);

/*2 JS OOP*/ 

/*JS OOP 1*/
class Human {
    constructor(name) {
        this.name = name;
    }

    greeting() {
        console.log('Hi! I\'m ' + this.name + '.');
    }
}

let p = new Human("Brooke");
p.greeting();

/*JS OOP 2*/
class randomPerson {
    constructor(name) {
        this.name = name;
    }

    introduce() {
        console.log(`Hi! I am ${this.name}.`);
    }
}

let names = ["Brooke", "Sarah", "Mya"];
names.forEach(name => new randomPerson(name).introduce());
