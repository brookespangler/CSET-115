class Matrix2x2 {
    constructor(values = [1, 0, 0, 1]) {
      if (values.length !== 4) {
        throw new Error("Matrix must be initialized with an array of 4 elements.");
      }
      this.values = values;
    }
  
    get(x, y) {
      if (x < 0 || x > 1 || y < 0 || y > 1) {
        throw new Error("Index out of bounds for a 2x2 matrix.");
      }
      return this.values[x * 2 + y];
    }
  
    scalarMultiply(scalar) {
      return new Matrix2x2(this.values.map(val => val * scalar));
    }
  
    add(other) {
      if (!(other instanceof Matrix2x2)) {
        throw new Error("Can only add another Matrix2x2.");
      }
      return new Matrix2x2(this.values.map((val, i) => val + other.values[i]));
    }
  
    subtract(other) {
      if (!(other instanceof Matrix2x2)) {
        throw new Error("Can only subtract another Matrix2x2.");
      }
      return new Matrix2x2(this.values.map((val, i) => val - other.values[i]));
    }
  
    determinant() {
      const [a, b, c, d] = this.values;
      return a * d - b * c;
    }
  
    inverse() {
      const det = this.determinant();
      if (det === 0) {
        throw new Error("Matrix is singular and cannot be inverted.");
      }
      const [a, b, c, d] = this.values;
      return new Matrix2x2([d / det, -b / det, -c / det, a / det]);
    }
  
    multiply(other) {
      if (!(other instanceof Matrix2x2)) {
        throw new Error("Can only multiply by another Matrix2x2.");
      }
      const [a1, b1, c1, d1] = this.values;
      const [a2, b2, c2, d2] = other.values;
      return new Matrix2x2([
        a1 * a2 + b1 * c2, a1 * b2 + b1 * d2,
        c1 * a2 + d1 * c2, c1 * b2 + d1 * d2
      ]);
    }
  
    toString() {
      return `[${this.get(0, 0)} ${this.get(0, 1)}]\n[${this.get(1, 0)} ${this.get(1, 1)}]`;
    }
  }
  
  class MatrixCollection {
    constructor() {
      this.matrices = [];
    }
  
    addMatrix(matrix) {
      if (!(matrix instanceof Matrix2x2)) {
        throw new Error("Only Matrix2x2 objects can be added.");
      }
      this.matrices.push(matrix);
    }
  
    updateMatrix(index, matrix) {
      if (!(matrix instanceof Matrix2x2)) {
        throw new Error("Only Matrix2x2 objects can be used for updates.");
      }
      if (index < 0 || index >= this.matrices.length) {
        throw new Error("Matrix index out of range.");
      }
      this.matrices[index] = matrix;
    }
  
    removeMatrix(index) {
      if (index < 0 || index >= this.matrices.length) {
        throw new Error("Matrix index out of range.");
      }
      this.matrices.splice(index, 1);
    }
  
    getMatrix(index) {
      if (index < 0 || index >= this.matrices.length) {
        throw new Error("Matrix index out of range.");
      }
      return this.matrices[index];
    }
  
    toString() {
      return this.matrices.map((matrix, i) => `Matrix ${i}:\n${matrix.toString()}`).join("\n\n");
    }
  }
  
  // Example usage:

  const matrix1 = new Matrix2x2([5, 6, 7, 8]);
  const matrix2 = new Matrix2x2([2, 3, 4, 5]);
  const matrix3 = new Matrix2x2([0, 9, 10, 4]);
  

  const collection = new MatrixCollection();
  collection.addMatrix(matrix1);
  collection.addMatrix(matrix2);
  collection.addMatrix(matrix3);
  
  console.log("Initial matrix collection:\n", collection.toString());
  
  const m1 = collection.getMatrix(0);
  const m2 = collection.getMatrix(1);
  
  // addition
  const resultAdd = m1.add(m2);
  console.log("Addition result:\n", resultAdd.toString());
  
  //subtraction
  const resultSubtract = m1.subtract(m2);
  console.log("Subtraction result:\n", resultSubtract.toString());
  
  //multiplication
  const resultMultiply = m1.multiply(m2);
  console.log("Multiplication result:\n", resultMultiply.toString());
  
  //determinant
  const det = m1.determinant();
  console.log("Determinant of matrix1:", det);
  
  //inverse
  const inv = m1.inverse();
  console.log("Inverse of matrix1:\n", inv.toString());
  