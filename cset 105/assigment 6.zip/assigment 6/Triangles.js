// 2 Triangles
class Point {
    constructor(x, y) {
      this.x = x;
      this.y = y;
    }
  }
  class Line {
    constructor(startPoint, endPoint) {
      if (!(startPoint instanceof Point) || !(endPoint instanceof Point)) {
        throw new Error("Both startPoint and endPoint must be instances of the Point class.");
      }
      this.startPoint = startPoint;
      this.endPoint = endPoint;
    }
  
    // distance formula
    getLength() {
      const dx = this.endPoint.x - this.startPoint.x;
      const dy = this.endPoint.y - this.startPoint.y;
      return Math.sqrt(dx * dx + dy * dy);
    }
  }
  class Triangle {
    constructor(pointA, pointB, pointC) {
      if (!(pointA instanceof Point) || !(pointB instanceof Point) || !(pointC instanceof Point)) {
        throw new Error("All points must be instances of the Point class.");
      }
      this.pointA = pointA;
      this.pointB = pointB;
      this.pointC = pointC;
  
 // the three sides of the triangle 
      this.sideAB = new Line(this.pointA, this.pointB);
      this.sideBC = new Line(this.pointB, this.pointC);
      this.sideCA = new Line(this.pointC, this.pointA);
    }
  
   // will check if it is a valid or invalid triangle. 
   /*will check if the largest side's length is smaller 
   than the other two lengths of the sides combined. */
    isValidTriangle() {
      const lengthAB = this.sideAB.getLength();
      const lengthBC = this.sideBC.getLength();
      const lengthCA = this.sideCA.getLength();
  
      return (lengthAB + lengthBC > lengthCA) &&
             (lengthBC + lengthCA > lengthAB) &&
             (lengthCA + lengthAB > lengthBC);
    }
  
    // Method for perimeter
    getPerimeter() {
      if (!this.isValidTriangle()) {
        return NaN;
      }
  
      return this.sideAB.getLength() + this.sideBC.getLength() + this.sideCA.getLength();
    }
  
    // Shoelace formula
    getArea() {
      if (!this.isValidTriangle()) {
        return NaN;
      }
  
      const x1 = this.pointA.x, y1 = this.pointA.y;
      const x2 = this.pointB.x, y2 = this.pointB.y;
      const x3 = this.pointC.x, y3 = this.pointC.y;
  
      return Math.abs((x1 * y2 + x2 * y3 + x3 * y1 - y1 * x2 - y2 * x3 - y3 * x1) / 2);
    }
  }

// Triangle 1: Valid triangle
const triangle1 = new Triangle(new Point(0, 0), new Point(10, 0), new Point(0, 3));
console.log("Triangle 1:");
console.log("Perimeter:", triangle1.getPerimeter());
console.log("Area:", triangle1.getArea());

// Triangle 2: Invalid triangle (collinear points)
const triangle2 = new Triangle(new Point(0, 0), new Point(2, 0), new Point(800, 0));
console.log("\nTriangle 2:");
console.log("Perimeter:", triangle2.getPerimeter());  
console.log("Area:", triangle2.getArea()); 
